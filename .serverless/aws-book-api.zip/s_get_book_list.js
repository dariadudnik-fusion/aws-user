
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'dashadev',
  applicationName: 'aws-book-api',
  appUid: 'Xh6Z7lSmMwJpVy5gsd',
  orgUid: '4bc5bf56-caae-4aeb-9b9a-c2908f73ecca',
  deploymentUid: '250d1ff3-767b-4fce-bfa2-980c60aa988d',
  serviceName: 'aws-book-api',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'aws-book-api-dev-get-book-list', timeout: 6 };

try {
  const userHandler = require('./index.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}