const { responseBuilder, errorBuilder } = require("./helpers/response.js");
const { getBooksById } = require("./data/getBooksById");
const { validateMethod } = require('./helpers/validation')

exports.handler = async (event) => {
    try {
        const { pathParameters, requestContext } = event;
        const { http } = requestContext;
        const id = pathParameters.id;
        // validateMethod(http, "GET");
        console.log('event', event);
        console.log('http', http);
        console.log('requestContext', requestContext);
        console.log(http !== "GET");

        const result = await getBooksById(id);

        return responseBuilder("200", result);
    } catch (error) {
        return errorBuilder(error);
    }
};
